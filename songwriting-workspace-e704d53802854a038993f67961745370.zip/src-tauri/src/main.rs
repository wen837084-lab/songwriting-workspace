#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    songwriting_workspace_lib::run();
}
